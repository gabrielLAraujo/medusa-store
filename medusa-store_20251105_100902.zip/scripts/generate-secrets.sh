#!/bin/bash

# Script para gerar secrets de segurança para Medusa.js

echo "🔐 Gerando secrets de segurança para Medusa.js..."
echo ""

JWT_SECRET=$(openssl rand -base64 32)
COOKIE_SECRET=$(openssl rand -base64 32)

echo "Copie estas variáveis para seu arquivo .env no Coolify:"
echo ""
echo "# Security Secrets - Gerados em $(date)"
echo "JWT_SECRET=$JWT_SECRET"
echo "COOKIE_SECRET=$COOKIE_SECRET"
echo ""
echo "# CORS - Atualize com seu domínio"
echo "STORE_CORS=https://desenvolvereviver.com"
echo "ADMIN_CORS=https://desenvolvereviver.com,https://admin.desenvolvereviver.com"
echo ""
echo "# Database - Configure no Coolify"
echo "DATABASE_URL=postgresql://usuario:senha@postgres:5432/medusa_db"
echo "REDIS_URL=redis://redis:6379"
echo ""
echo "# Environment"
echo "NODE_ENV=production"
echo ""
echo "✅ Secrets gerados com sucesso!"

